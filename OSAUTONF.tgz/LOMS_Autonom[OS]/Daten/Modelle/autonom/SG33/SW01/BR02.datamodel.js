/**
 * Laden der UTILS, damit die im datamodel nur noch aufgerufen werden müssen
 */
load("Funktionen\\Utils.js")
load("Funktionen\\autonom\\AutonomUtils.js");