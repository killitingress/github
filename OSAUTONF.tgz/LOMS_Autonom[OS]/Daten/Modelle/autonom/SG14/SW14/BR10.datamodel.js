/**
 * Laden der UTILS, damit die im datamodel nur noch aufgerufen werden müssen
 * 11.12.2020 - nun voll qualifiziert, weil sonst Fehlermeldung "is beeing loaded"
 */
load("\\\\LOMS_Framework\\Funktionen\\Utils.js");
load("Funktionen\\autonom\\AutonomUtils.js")