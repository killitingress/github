/**
 * Laden der UTILS, damit die im datamodel nur noch aufgerufen werden müssen
 */
load("Funktionen\\Utils.js");
load("Funktionen\\autonom\\AutonomUtils.js")
var AuswahlBBU = {
  beglaubigte: "beglaubigte",
  unbeglaubigte: "unbeglaubigte",
  vollstreckbareAusfertigungGSU: "vollstreckbareAusfertigungGSU",
  rekopieBestellungsurkunde: "rekopieBestellungsurkunde"
}

var ist = function (d, x) {
  if (x === undefined) throw "ist: x undefined"
  return d.valueOf() === x
 }


